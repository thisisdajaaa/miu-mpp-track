package midterm_exam.constants;

public enum ItemType {
    BOOK,
    CD
}

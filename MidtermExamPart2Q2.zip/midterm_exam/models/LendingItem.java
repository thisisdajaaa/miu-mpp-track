package midterm_exam.models;

import midterm_exam.constants.ItemType;

public abstract class LendingItem {
    private Integer numCopiesInLib;

    public LendingItem(Integer numCopiesInLib) {
        this.numCopiesInLib = numCopiesInLib;
    }

    public Integer getNumCopiesInLib() {
        return numCopiesInLib;
    }

    public void setNumCopiesInLib(Integer numCopiesInLib) {
        this.numCopiesInLib = numCopiesInLib;
    }
}

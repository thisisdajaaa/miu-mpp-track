package lesson3.prob4;

public abstract class Property {
    public abstract double computeRent();
}

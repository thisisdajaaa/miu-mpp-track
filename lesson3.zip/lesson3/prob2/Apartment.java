package lesson3.prob2;

public class Apartment {
    private Double rent;

    public Apartment(Double rent) {
        this.rent = rent;
    }

    public Double getRent() {
        return rent;
    }

    public void setRent(Double rent) {
        this.rent = rent;
    }
}

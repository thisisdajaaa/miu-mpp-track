package lesson5.prob2.interfaces;

public interface IShape {
    public Double computeArea();
}

package final_exam.part2q1.model;

public enum AccountType {
    CHECKING, SAVINGS, LOAN
}
